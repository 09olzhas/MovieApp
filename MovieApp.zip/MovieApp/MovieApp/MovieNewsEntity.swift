//
//  MovieNewsEntity.swift
//  MovieApp
//
//  Created by admin on 11.02.2021.
//

import Foundation
class MovieNewsEntity: Decodable {
    let results: [Movie]
    
    class Movie: Decodable {
        let id: Int
        let originalTitle: String
        let releaseDate: String
        let voteAverage: Double
        let posterPath: String?
        
       enum CodingKeys: String, CodingKey {
     case id
     case originalTitle = "original_title"
     case releaseDate = "release_date"
     case voteAverage = "vote_average"
     case posterPath = "poster_path"
    }
        
    required init(from decoder: Decoder) throws {
     let container = try decoder.container(keyedBy: CodingKeys.self)
     self.id = try container.decode(Int.self, forKey: .id)
     self.originalTitle = try container.decode(String.self, forKey: .originalTitle)
     self.releaseDate = try container.decode(String.self, forKey: .releaseDate)
     self.voteAverage = try container.decode(Double.self, forKey: .voteAverage)
     self.posterPath = try? container.decodeIfPresent(String.self, forKey: .posterPath)
            
        }
    }
}
