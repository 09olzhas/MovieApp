//
//  MovieCell.swift
//  MovieApp
//
//  Created by Admin on 10.02.2021.
// wdfd

import UIKit

class MovieCell: UITableViewCell {
    public static let identifier: String = "MovieCell"

    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var movieNameLabel: UILabel!
    @IBOutlet weak var labelContainerView: UIView!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var releaseDateLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        
        posterImageView.layer.cornerRadius = 0
        posterImageView.layer.masksToBounds = true
        
        labelContainerView.layer.cornerRadius = 20
        labelContainerView.layer.masksToBounds = true
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
